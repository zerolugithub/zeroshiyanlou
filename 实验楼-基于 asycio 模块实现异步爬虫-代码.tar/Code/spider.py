import csv
import asyncio
import aiohttp
import async_timeout

from scrapy.http import HtmlResponse

results = []

async def fetch(session,url):
    with async_timeout.timeout(10):
        async with session.get(url) as response:
            return await response.text(encoding='utf-8')

def parse(url,body):
    response = HtmlResponse(url=url,body=body,encoding='utf-8')
    for github  in response.css('li[itemprop="owns"]'):
        name = github.css('a[itemprop="name codeRepository"]::text').re_first(r'\n\s*(.*)')
        update_time = github.css('relative-time::attr(datetime)').extract_first()
        results.append((name,update_time))

async def task(url):
    async with aiohttp.ClientSession() as session:
        body = await fetch(session,url)
        parse(url,body)
def main():
    loop = asyncio.get_event_loop()
    url_template =  ["https://github.com/shiyanlou?tab=repositories",
            'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoxOTo1N1rOBZKWMA%3D%3D&tab=repositories',
            'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK5MjAxNS0wMS0yNVQxMTozMTowNyswODowMM4Bxrsx&tab=repositories',
            'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK5MjAxNC0xMS0yMFQxMzowMzo1MiswODowMM4BjkvL&tab=repositories',
            ]
    tasks = [task(i) for i in url_template]
    loop.run_until_complete(asyncio.gather(*tasks))
    with open("shiyanlou-repos.csv",'w',newline="") as f:
        writer = csv.writer(f)
        writer.writerows(results)
if __name__ == '__main__':
    main()



