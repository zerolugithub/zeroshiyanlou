#!/usr/bin/env python3

import sys
from pymongo import MongoClient


def get_rank(user_id):
    client = MongoClient()
    db = client.shiyanlou
    contests = db.contests
    rank = db.contests.find({"user_id":user_id},{"_id":0,"challenge_id":1,    "score":1,"submit_time":1}).sort({"score":-1,"submit_time":1}).limit(1)

    return rank
    #return rank, score, submit_time

if __name__ == "__main__":
    user_id = 1
    userdata = get_rank(user_id)
    print(userdata)
