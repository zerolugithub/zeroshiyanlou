from flask import Blueprint, render_template, url_for, flash, redirect,request
from simpledu.models import Course, User
from simpledu.forms import LoginForm, RegisterForm
from flask_login import login_user, logout_user, login_required
import re
front = Blueprint('front', __name__)

@front.route('/')
def index():
    courses = Course.query.all()
    return render_template('index.html', courses=courses)

@front.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        username = User.query.filter_by(username=form.username.data).first()
        login_user(username, form.remember_me.data)
        return redirect(url_for('.index'))
    return render_template('login.html', form=form)

@front.route('/logout')
@login_required
def logout():
    logout_user()
    flash('logout success', 'success')
    return redirect(url_for('.index'))

@front.route('/register', methods=['GET', 'POST'])
def register():
    #pattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)"
    form = RegisterForm()
    #if request.method == "POST":
    #    username= request.form.get("username")
    #    if not re.match(pattern,username):
    #        flash("only number and character","fail")
    if form.validate_on_submit():
        form.create_user()
        flash('register success', 'success')
        return redirect(url_for('.login'))
    return render_template('register.html', form=form)

