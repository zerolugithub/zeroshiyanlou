#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/10/24 10:48
# @Author  : zero
# @File    : app.py.py
# @Software: PyCharm

from flask import Flask,render_template,abort
import json
import os
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__,template_folder="../templates")
app.config["SQLALCHEMY_DATABASE_URI"]= "mysql://root@localhost/test"
db = SQLAlchemy(app)

class File(db.Model): 
    id = db.Column(db.Integer,primary_key = True)
    title = db.Column(db.String(80))
    create_time = db.Column(db.DateTime)
    category_id = db.Column(db.Integer,db.ForeignKey("category.id"))
    category = db.relationship("Category",backref=db.backref("files",lazy="dynamic"))
    content = db.Column(db.Text)
    
    def __init__(self,title,category,content,create_time=None):
        self.title = title
        if create_time is None:
            create_time = datetime.utcnow()
        self.create_time = create_time
        self.category = category
        self.content = content
    def __repr__(self):
        return "{} {} {}".format(self.content,self.create_time,self.category.title)

class Category(db.Model):
    id = db.Column(db.Integer,primary_key = True)
    title = db.Column(db.String(80))

    def __init__(self,title):
        self.title = title
    def __repr__(self):
        return "{} ".format(self.title)






def handleJson(fileName,key):
    jf = json.load(open(fileName,"r"))
    return jf[key]



@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"),404

@app.route("/")
def index():
#    os.chdir("../files")
#    titles = []
#    for root,dir,files in os.walk(os.getcwd()):
#        for f in files:
#            titles.append(handleJson(f,"title"))
    titles = File.query.all()
   

    return render_template("index.html",titles=titles)


@app.route("/files/<file_id>")
def files(file_id):
    #os.chdir("../files")
    #jf = os.getcwd()+"/"+ filename+".json"
    #if not os.path.exists(jf):
    #    abort(404)
    #fileContent = handleJson(jf,"content")
    #import re
    #fileContents =  re.split(r" \\n | \\\\n",fileContent)
    fileContents = File.query.filter_by(id = file_id).first_or_404()
    return render_template("file.html",fileContents = fileContents)

if __name__ == "__main__":
    app.run(debug=True,port=3000)
