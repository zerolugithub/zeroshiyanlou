# -*- coding: utf-8 -*-
import scrapy
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from flask_doc.items import FlaskDocItem
import re
from scrapy.selector import Selector

class FlaskSpider(scrapy.spiders.CrawlSpider):
    name = 'flask'
    start_urls = ['http://flask.pocoo.org/docs/1.0/']
    
    rules = [Rule(LinkExtractor(allow='/flask.pocoo.org/docs/1.0'),
            callback="parse_page",
            follow=True)
            ]

    def parse_page(self, response):
        item = FlaskDocItem()
        sel = Selector(response)
        url = response.url
        text =  response.body
        text = text.decode("utf-8")
        re_h = re.compile('</?\w+[^>i]*>')
        text_h = re_h.sub('',text)
        moreBlank = re.compile('\\s{2,}')
        textAll = moreBlank.sub('',text_h)
        
        item["url"] = url
        item["text"] = textAll

        yield item
