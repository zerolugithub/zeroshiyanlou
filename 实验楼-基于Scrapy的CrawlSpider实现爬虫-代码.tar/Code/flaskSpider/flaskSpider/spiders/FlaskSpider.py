# -*- coding: utf-8 -*-
import scrapy
from scrapy.spiders import Rule
from scrapy.linkextractors import LibkExtractor
from flask_doc.items import PageItem

class FlaskspiderSpider(scrapy.Spider.CrwalSpider):
    name = 'FlaskSpider'
    allowed_domains = ['flask.pocoo.org']
    start_urls = ['http://flask.pocoo.org/']

    def parse(self, response):
        pass
