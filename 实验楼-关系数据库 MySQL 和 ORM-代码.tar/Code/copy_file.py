#!/usr/bin/env python3

def copy_file(src_file,dst_file):
    with open(src_file,"r") as sf:
        with open(dst_file,"w") as df:
             df.write(sf.read())

if __name__ == "__main__":
    copy_file("test.txt","zero.txt")

