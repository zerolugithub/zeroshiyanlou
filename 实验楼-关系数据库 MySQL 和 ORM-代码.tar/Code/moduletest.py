#! /usr/bin/env python3

from louplus.test.hello import message

print(message)
