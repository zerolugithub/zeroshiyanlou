#!/usr/bin/env python3

import os
import threading

def hello(name):
    print("child thread:{}".format(threading.get_ident()))
    print("Hello"+name)
def main():
    p = threading.Thread(target=hello,args=("shiyanlou",))
    p.start()
    p.join()
    print("main thread:{}".format(threading.get_ident()))

if __name__ == "__main__":
    main()
