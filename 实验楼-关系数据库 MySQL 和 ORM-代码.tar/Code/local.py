#!/usr/bin/env python3

def change():
    global a
    a = 100
    print(a)
a = 1
print("before",a)
print("non",end= " ")
change()
print("after",a)
