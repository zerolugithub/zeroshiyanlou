#!/usr/bin/env python3

import sys

argvs = sys.argv[1:]

diffSet = set()

for argv in argvs:
    diffSet.add(argv)
for i in diffSet:
    print(i,end= " ")
print()
