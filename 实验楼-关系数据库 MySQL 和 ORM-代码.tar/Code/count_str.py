#!/usr/bin/env python3

def char_count(str):
    charDict = {}    
    for char in str:
        charDict[char]= charDict.get(char,0) + 1
    print(charDict)
if __name__ == "__main__":
    s = input("please input str:")
    char_count(s)
