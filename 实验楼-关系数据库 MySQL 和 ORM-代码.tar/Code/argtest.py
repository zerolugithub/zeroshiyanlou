#!/usr/bin/env python3

import sys

print(sys.argv)
print(len(sys.argv))

if __name__ == "__main__":
    for arg  in sys.argv:
        print(arg)


