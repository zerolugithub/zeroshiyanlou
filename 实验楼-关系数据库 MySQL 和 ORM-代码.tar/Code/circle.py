#!/usr/bin/env python3

from math  import pi

result = 5 * 5 *pi

print("the circle Area is : {}".format(result))
