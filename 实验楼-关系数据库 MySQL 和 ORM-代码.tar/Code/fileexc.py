#! /usr/bin/env python3

fileName = input("please input file path:")

try:
    f = open(fileName)
    print(f.read())
    f.close()
except:
    print("File not found")
finally:
    print("File close")



