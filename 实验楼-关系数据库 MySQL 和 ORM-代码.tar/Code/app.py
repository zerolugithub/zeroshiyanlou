#!/usr/bin/env python3
#-*- coding:utf-8 -*-

from flask import Flask,render_template

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True

def hidder_email(email):
    parts = email.split("@")
    parts[0] = "******"
    return "@".join(parts)
app.add_template_filter(hidder_email)

@app.route("/")
def index():
    teacher={
        "name": "Aiden",
        "email": "luojin@test.com"
    }
    course = {
        "name": "Python Basic",
        "teacher": teacher,
        "is_private": False,
        "tags": ["python","big data","Linux"]
    }
    return render_template("index.html",course=course)
