#!/usr/bin/env python3

import sys
argvs = sys.argv[1:]
littleThree = []
biggerThree = []


for argv in argvs:
    if len(argv) <=3:
        littleThree.append(argv)
    else:
        biggerThree.append(argv)
for i in littleThree:
    print(i,end=" ")
print()
for i in biggerThree:
    print(i,end=" ")
print()
