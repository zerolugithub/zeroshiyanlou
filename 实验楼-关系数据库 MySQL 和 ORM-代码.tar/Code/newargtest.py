#!/usr/bin/env python3

import sys

#print(sys.argv)
#print(len(sys.argv))

for arg  in sys.argv[1:]:
     if len(arg) > 3:
         print("length bigger is: {}".format(arg))


