#!/usr/bin/env python3

from multiprocessing import Pipe,Process

c1 ,c2 = Pipe()

def send():
    data = "hello shiyanlou"
    c1.send(data)
    print("Send Data:{}".format(data))
def recv():
    data = c2.recv()
    print("Receive Data:{}".format(data))

def main():
    Process(target=send).start()
    Process(target=recv).start()

if __name__ == "__main__":
   main()
