#!/usr/bin/env python3

def compute(value, base=None):
    base = base[:]
    base.append(value)
    result = sum(base)
    base = None
    print(result)
if __name__ == "__main__":
    testlist = [10,20,30]
    compute(base=testlist,value=15)
    compute(base=testlist,value=25)
    compute(base=testlist,value=35)
