#!/usr/bin/env python3

class UserData:
    def __init__(self,ID,name):
        self._ID = ID
        self._name = name
    def __repr__(self):
        return "ID:{} Name:{}".format(self._ID,self._name)
class NewUser(UserData):
    owner = "zero"
    group = "shiyanlou-ouplus"
    #def get_name(self):
    #    return self.name
    #def set_name(self,name):
    #    self.name = name
    @classmethod
    def get_group(cls):
        return cls.group
    @staticmethod
    def format_userdata(id,name):
        return "{}\'s id is {}".format(name,id)
      
    def __repr__(self):
        return "{}\'s id is {}".format(self._name,self._ID)
    @classmethod
    def get_owner(cls):
        return cls.owner
    @property    
    def name(self):
        return self._name
    @name.setter
    def name(self,value):
        if len(value) > 3:
            self._name = value
        else:
            print("ERROR")    
if __name__ == "__main__":
    #user1 = UserData("101","Jack")
    user3 = NewUser("101","Jack")
    #user2 = UserData("102","Louplus")
    #user1.set_name("Jackie")
    #user2 = NewUser("102","Louplus")
    #print(user1)
    #print(user2)
    #print(user1.get_owner())
    user3.name = "Lou"
    user3.name = "jacketet"
    
    user4 = NewUser("102","ddddLouplus")
    print(user3.name)
    print(user4.name) 
    print(NewUser.get_group())
    print(NewUser.format_userdata(109,"Lucy"))
