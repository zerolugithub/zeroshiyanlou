#!/usr/bin/env python3

import json

jsonData = '[{"user_id":1000,"name":"Shiyan","pass":10,"study_time":50},{"user_id":2000,"name":"Shiyan","pass":15,"study_time":171}]'
jd = json.loads(jsonData)
json.dump(jd,open("/tmp/jsontest.json","w"))

