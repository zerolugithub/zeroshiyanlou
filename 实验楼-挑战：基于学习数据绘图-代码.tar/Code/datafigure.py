import pandas as pd
from matplotlib import pyplot as plt

def data_plot(file):
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    ax.set_title("StudyData")
    ax.set_xlabel("User ID")
    ax.set_ylabel("Study Time")
    data = pd.read_json(file,typ="frame")
    dataN = pd.DataFrame(data.groupby('user_id').sum())
    ax.plot(dataN)
    plt.show()
    return ax


if __name__ == "__main__":
    data_plot("user_study.json")
