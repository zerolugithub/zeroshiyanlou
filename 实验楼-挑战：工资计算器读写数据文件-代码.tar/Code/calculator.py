#!/usr/bin/env python3

import sys
import csv
import os

class Args():
    def __init__(self):
        if len(sys.argv) < 7:
            print("Parameter Error")
            print("-c -d -o ")
            sys.exit()
        else:
            self.argvs = sys.argv[1:]
    def getFile(self,option):
        return  self.argvs[self.argvs.index(option) + 1]
        
class Config():
    def __init__(self):
        self.config = self._read_config()
    def _read_config(self):
        config = {}
        configFile = Args().getFile("-c")
       
        if os.path.exists(configFile):  
            with open(configFile) as f:
                for data in f.readlines():
                    config[data.split("=")[0].strip()] = float(data.split("=")[1].strip())
        else:    
            print("ConfigFile not found")
            sys.exit(-1)
        return config
   
    def get_config(self,key):
        return self.config[key]        

class UserData():
    def __init__(self):
        self.userData = self._read_users_data()
    def _read_users_data(self):
        userData = {}
        userDataFile = Args().getFile("-d")
        if os.path.exists(userDataFile):
            with open(userDataFile) as f:
                for data in csv.reader(f):
                    userData[data[0]] = float(data[1])
        else:
            print("UserDataFile not found")
            sys.exit(-1)
        return userData

class IncomeTaxCalculator():
    def _ynssde(self,ynse,rate,kcs):
        return ynse*rate - kcs
    def _shSal(self,gh,sqSal):
        JiShuL = Config().get_config("JiShuL")
        JiShuH = Config().get_config("JiShuH")
        if sqSal < JiShuL:
            sbje = JiShuL*0.165
            gsje = 0.00 
        elif JiShuL <= sqSal <= JiShuH:
            sbje = sqSal * 0.165
            ynse = sqSal - sbje - 3500
            if ynse < 0 :
               gsje = 0.00
            else: 
                if 0 <= ynse <= 1500:
                    gsje = self._ynssde(ynse,0.03,0)
                elif 1500 < ynse <= 4500:
                    gsje = self._ynssde(ynse,0.1,105)
                elif 4500 < ynse <= 9000:
                    gsje = self._ynssde(ynse,0.2,555)
                elif 9000 < ynse <= 35000:
                    gsje = self._ynssde(ynse,0.25,1005)
        elif sqSal > JiShuH:
            sbje = JiShuH * 0.165
            ynse = sqSal - sbje - 3500
            if 0 <= ynse <= 1500:
                gsje = self._yyssde(ynse,0.03,0)
            elif 1500 < ynse <= 4500:
                gsje = self._ynssde(ynse,0.1,105)
            elif 4500 < ynse <= 9000:
                gsje = self._ynssde(ynse,0.2,555)
            elif 9000 < ynse <= 35000:
                gsje = self._ynssde(ynse,0.25,1005)
            elif 35000 < ynse <= 55000:
                gsje = self._ynssde(ynse,0.3,2755)
            elif 55000 < ynse <= 80000:
                gsje = self._ynssde(ynse,0.35,5505)
            else:
                gsje = self._ynssde(ynse,0.45,13505)
        salAfter = sqSal-sbje-gsje
        return "{},{:.2f},{:.2f},{:.2f},{:.2f}".format(gh,sqSal,sbje,gsje,salAfter)

    def calc_for_all_userdata(self):
        jsonStr = []
        for key,value in UserData().userData.items():
            jsonStr.append(self._shSal(key,value).split(","))
        return jsonStr
           
    def export(self,exportFile,default='csv'):
        result = self.calc_for_all_userdata()
        print(result)
        with open(exportFile,"w") as f:
            csv.writer(f).writerows(result)
if __name__ == "__main__":
    arg = Args()
    exportFile = arg.getFile("-o")
    #ud = UserData()
    it = IncomeTaxCalculator()
    #for key,value in ud.userData.items():
    #it.calc_for_all_userdata()
    it.export(exportFile)

    
    
