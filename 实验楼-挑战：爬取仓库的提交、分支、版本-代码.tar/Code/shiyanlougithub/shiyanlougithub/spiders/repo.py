# -*- coding: utf-8 -*-
import scrapy
from shiyanlougithub.items import ShiyanlougithubItem

class RepoSpider(scrapy.Spider):
    name = 'repo'
    allowed_domains = ['github.com']
    @property
    def start_urls(self):
        start_urls = ["https://github.com/shiyanlou?tab=repositories",
                      'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoxOTo1N1rOBZKWMA%3D%3D&tab=repositories',
                      'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK5MjAxNS0wMS0yNVQxMTozMTowNyswODowMM4Bxrsx&tab=repositories',
                      'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK5MjAxNC0xMS0yMFQxMzowMzo1MiswODowMM4BjkvL&tab=repositories',
                      ]
        return start_urls

    def parse(self, response):
        for github in response.css('li[itemprop="owns"]'):
            item = ShiyanlougithubItem()
            item['name'] = github.css('a[itemprop="name codeRepository"]::text').re_first(r'\n\s*(.*)')
            item["update_time"] = github.css('relative-time::attr(datetime)').extract_first()

            url = response.urljoin(github.css('a::attr(href)').extract_first())
            request = scrapy.Request(url,callback=self.parse_content)
            request.meta['item'] = item
            yield request

    def parse_content(self,response):
        item = response.meta['item']
        item["commits"]= response.css('span[class="num text-emphasized"]::text').re(r'\n\s*(.*)\n')[0]
        item['branches'] = response.css('span[class="num text-emphasized"]::text').re(r'\n\s*(.*)\n')[1]
        item['releases'] = response.css('span[class="num text-emphasized"]::text').re(r'\n\s*(.*)\n')[2]
        yield item
