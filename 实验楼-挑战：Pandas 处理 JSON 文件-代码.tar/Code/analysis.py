import pandas as pd
import sys

def analysis(file,user_id):
    times = 0
    minutes = 0
    data = pd.read_json(file,typ="frame")
    for df in data["user_id"]:
        if df == user_id:
            minutes = data[data['user_id'] == user_id]["minutes"].sum()
            times += 1
    return times,minutes
if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Parameter error")
        sys.exit()
    file = sys.argv[1]
    user_id = int(sys.argv[2])
    t,m = analysis("user_study.json",user_id)

    print(t,m)

